#!/usr/bin/env python3
"""Prepare/execute the small public-generation pilot against public fixtures.

This adapter is intentionally separate from the held-out importer. It reads
only the checked-in public development package and archived pilot artifacts.
It requires explicit correctness-execution authorization on the command line,
and never edits or repairs a generated candidate.
"""

from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from typing import Any


CAMPAIGN = Path(__file__).resolve().parents[1]
DEFAULT_REPO = Path("<RECORDED_REPOSITORY>")
AMENDMENT_PATH = CAMPAIGN / "pre-execution-amendment-2026-10-15.json"
AMENDMENT_2_PATH = CAMPAIGN / "pre-execution-amendment-2026-10-15-02.json"
AMENDMENT_2_SHA256 = "e300ba55f54d689aaf368d1cd8fe4a4105b026a64d983578179a69431c35b12f"
EXPECTED_CURRENT_STAGED_TREE = "b2004326c008540d4e57880352bfefd1c8409e37"
PUBLIC_PACKAGE_SHA256 = "e02fc57cb4a40c5ee7f4deb4dc82c80f8a2f649bc614b3adb88295f3ccff1e84"
EVALUATOR_SHA256 = "9d639c17d0680bc718cc858c4a6f50f116aff1783ece1bf49f97e0404a376fc7"
HARNESS_SHA256 = "26dd34874ea76748563e3c560ffec51ef0fb87b2d10a0c8f9d7a51dde1121ab6"
MANIFEST_CATALOG_SHA256 = "10d776484d2f19a1fb478f9d94882cc056609c7063ef51fd63cb847391b712cc"
TASK_ORDER = ("filesystem_inventory", "layered_config_merge", "typed_event_normalizer")
EVENT_FIELD_ORDER = ("event_id", "occurred_at", "kind", "source", "actor")
TASK_OUTPUT = {
    "filesystem_inventory": "reports/inventory.txt",
    "layered_config_merge": "reports/effective.json",
    "typed_event_normalizer": "reports/normalized.jsonl",
}
ARM_EXTENSION = {"bash": ".sh", "nushell": ".nu", "execute_program": ".program"}
PARTICIPANT_ARM = {"bash": "bash", "nushell": "nushell", "execute": "execute_program"}


class PilotError(ValueError):
    """The pilot evidence or invocation does not match its recorded contract."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def manifest_catalog_digest(root: Path) -> str:
    """Hash each manifest's relative path and complete bytes in stable order."""
    if not root.is_dir() or root.is_symlink():
        raise PilotError(f"manifest directory must be a regular directory: {root}")
    files: list[Path] = []
    for parent, dirs, names in os.walk(root, followlinks=False):
        parent_path = Path(parent)
        for name in list(dirs):
            path = parent_path / name
            if path.is_symlink():
                raise PilotError(f"manifest catalog contains a directory symlink: {path}")
        dirs.sort()
        for name in sorted(names):
            path = parent_path / name
            if path.is_symlink() or not path.is_file():
                raise PilotError(f"manifest catalog contains a non-regular file: {path}")
            files.append(path)
    if not files:
        raise PilotError(f"manifest catalog is empty: {root}")
    digest = hashlib.sha256()
    for path in sorted(files, key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        data = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


def git_commit_tree(repo: Path, commit_sha: str) -> str:
    """Resolve a supplied commit read-only and return its immutable tree SHA."""
    if not re.fullmatch(r"[a-f0-9]{40}", commit_sha):
        raise PilotError("actual commit SHA must be a lowercase 40-character Git SHA")
    try:
        resolved = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--verify", f"{commit_sha}^{{commit}}"],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip().lower()
        tree = subprocess.run(
            ["git", "-C", str(repo), "show", "-s", "--format=%T", resolved],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip().lower()
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as error:
        raise PilotError(f"cannot verify the supplied actual commit SHA: {error}") from error
    if resolved != commit_sha or not re.fullmatch(r"[a-f0-9]{40}", tree):
        raise PilotError("supplied actual commit is not a full commit SHA in the recorded repository")
    return tree


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def expected_bytes(task_id: str, expected: Any) -> bytes:
    """Encode the generation brief's exact output bytes for a public oracle."""
    if task_id == "filesystem_inventory":
        if not isinstance(expected, str):
            raise PilotError("filesystem oracle must contain text")
        return expected.encode("utf-8")
    if task_id == "layered_config_merge":
        # The shared brief requires compact JSON, recursively sorted keys, LF.
        return (json.dumps(expected, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    if task_id == "typed_event_normalizer":
        if not isinstance(expected, list):
            raise PilotError("event oracle must contain an array")
        lines = []
        for row in expected:
            if not isinstance(row, dict) or set(row) != set(EVENT_FIELD_ORDER):
                raise PilotError("event oracle fields do not match the shared field-order contract")
            ordered = {field: row[field] for field in EVENT_FIELD_ORDER}
            lines.append(json_bytes(ordered))
        return b"".join(line + b"\n" for line in lines)
    raise PilotError(f"unexpected public task {task_id!r}")


def _under(root: Path, path: Path, label: str) -> Path:
    resolved_root = root.resolve(strict=True)
    resolved = path.resolve(strict=True)
    if resolved == resolved_root or resolved_root not in resolved.parents:
        raise PilotError(f"{label} must remain inside {root}")
    return resolved


def _recorded_participants(campaign: Path) -> list[dict[str, Any]]:
    ledger = json.loads((campaign / "dispatch-ledger.json").read_text(encoding="utf-8"))
    participants = ledger.get("participants")
    if not isinstance(participants, list) or len(participants) != 9:
        raise PilotError("dispatch ledger must preserve exactly nine first-cohort cells")
    selected: list[dict[str, Any]] = []
    for item in participants:
        participant_id = item["participant_id"]
        arm = item["arm"]
        task_id = item["task_id"]
        if task_id not in TASK_ORDER or arm not in {"bash", "nushell", "execute"}:
            raise PilotError(f"unexpected ledger participant cell {participant_id!r}")
        row = {
            "participant_id": participant_id,
            "cohort": "initial",
            "task_id": task_id,
            "arm": PARTICIPANT_ARM[arm],
            "model": item.get("model", "gpt-6-luna"),
            "reasoning_effort": item.get("reasoning_effort", "max"),
            "dispatched_at_utc": item.get("dispatched_at_utc"),
            "return_observed_at_utc": item.get("return_observed_at_utc"),
            "outcome": item.get("outcome"),
            "artifact_sha256": item.get("artifact_sha256"),
            "archive_path": item.get("archive_path"),
        }
        if row["artifact_sha256"]:
            archive = Path(str(row["archive_path"]))
            archive = _under(campaign / "archive" / "initial", archive, participant_id)
            if not archive.is_file() or sha256_file(archive) != row["artifact_sha256"]:
                raise PilotError(f"archived bytes do not match the first-cohort ledger for {participant_id}")
            row["archive_path"] = str(archive)
            row["artifact_bytes"] = archive.stat().st_size
        else:
            # Preserve the missing initial Bash filesystem artifact as a real
            # first-cohort result; the recovery artifact is never substituted.
            row["archive_path"] = None
            row["artifact_bytes"] = None
            if participant_id != "filesystem_inventory__bash":
                raise PilotError(f"unexpected missing first-cohort artifact: {participant_id}")
        selected.append(row)

    replacement = json.loads((campaign / "replacement-dispatch.json").read_text(encoding="utf-8"))
    replacement_path = _under(campaign / "archive" / "initial", Path(replacement["archive_path"]), "replacement archive")
    replacement_hash = replacement["artifact_sha256"]
    if not replacement_path.is_file() or sha256_file(replacement_path) != replacement_hash:
        raise PilotError("recovery replacement bytes do not match their separate dispatch record")
    selected.append({
        "participant_id": replacement["replacement_id"],
        "cohort": "recovery_replacement",
        "replaces_participant_id": replacement["replaces_cell"],
        "task_id": replacement["task_id"],
        "arm": PARTICIPANT_ARM[replacement["arm"]],
        "model": replacement["model"],
        "reasoning_effort": replacement["reasoning_effort"],
        "dispatched_at_utc": replacement["dispatched_at_utc"],
        "return_observed_at_utc": replacement["returned_observed_by_utc"],
        "outcome": replacement["outcome"],
        "artifact_sha256": replacement_hash,
        "artifact_bytes": replacement_path.stat().st_size,
        "archive_path": str(replacement_path),
    })
    return selected


def _fixture_root(case: dict[str, Any], task: dict[str, Any], candidate: Path) -> tuple[tempfile.TemporaryDirectory[str], Path, Path, dict[str, str]]:
    temporary = tempfile.TemporaryDirectory(prefix="public-generation-pilot-")
    root = Path(temporary.name)
    (root / "reports").mkdir()
    (root / "tmp").mkdir()
    (root / "home").mkdir()
    for relative, content in case["files"].items():
        path = root.joinpath(*Path(relative).parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    staged = root / ("candidate" + ARM_EXTENSION[task["arm"]])
    shutil.copyfile(candidate, staged)
    inputs = {item["program_input"]: item["default"] for item in task["inputs"]}
    inputs.update(case.get("inputs", {}))
    env = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": str(root / "home"),
        "TMPDIR": str(root / "tmp"),
        "LC_ALL": "C",
        "LANG": "C",
        "TZ": "UTC",
    }
    for item in task["inputs"]:
        env[item["environment"]] = inputs[item["program_input"]]
    return temporary, root, staged, {**{str(k): str(v) for k, v in inputs.items()}, **{f"env:{k}": v for k, v in env.items() if k.startswith("EVAL_")}}


def _actual_file(path: Path) -> dict[str, Any] | None:
    if path.is_symlink():
        return {"kind": "symlink", "target": os.readlink(path), "mode": stat.S_IMODE(path.lstat().st_mode)}
    if not path.is_file():
        return None
    data = path.read_bytes()
    return {
        "kind": "file",
        "mode": stat.S_IMODE(path.stat().st_mode),
        "sha256": sha256_bytes(data),
        "bytes": len(data),
        "content_base64": base64.b64encode(data).decode("ascii"),
    }


def _filesystem_state(root: Path) -> dict[str, dict[str, Any]]:
    """Capture names, types, modes, symlink targets, and exact file bytes."""
    state: dict[str, dict[str, Any]] = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        parent_path = Path(parent)
        for name in sorted(dirs):
            path = parent_path / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                state[relative] = {"kind": "symlink", "target": os.readlink(path), "mode": stat.S_IMODE(path.lstat().st_mode)}
            else:
                state[relative] = {"kind": "directory", "mode": stat.S_IMODE(path.stat().st_mode)}
        dirs[:] = [name for name in dirs if not (parent_path / name).is_symlink()]
        for name in sorted(files):
            path = parent_path / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                state[relative] = {"kind": "symlink", "target": os.readlink(path), "mode": stat.S_IMODE(path.lstat().st_mode)}
            elif path.is_file():
                data = path.read_bytes()
                state[relative] = {
                    "kind": "file",
                    "mode": stat.S_IMODE(path.stat().st_mode),
                    "bytes": len(data),
                    "sha256": sha256_bytes(data),
                    "content_base64": base64.b64encode(data).decode("ascii"),
                }
            else:
                state[relative] = {"kind": "other", "mode": stat.S_IMODE(path.lstat().st_mode)}
    return state


def _case_unavailable(task_id: str, case: dict[str, Any], reason: str) -> dict[str, Any]:
    expected = expected_bytes(task_id, case["expected"])
    return {
        "case_id": case["case_id"],
        "status": "unavailable",
        "reason": reason,
        "returncode": None,
        "stdout": {"bytes": 0, "sha256": sha256_bytes(b""), "base64": ""},
        "stderr": {"bytes": 0, "sha256": sha256_bytes(b""), "base64": ""},
        "expected_stdout": {"bytes": len(expected), "sha256": sha256_bytes(expected), "base64": base64.b64encode(expected).decode("ascii")},
        "stdout_exact_match": None,
        "stderr_oracle": "not specified by public task; no process ran",
        "output_file_exact_match": None,
        "filesystem_effects": None,
    }


def _run_case(
    task_id: str,
    task: dict[str, Any],
    case: dict[str, Any],
    arm: str,
    candidate: Path,
    *,
    execute_binary: Path,
    manifest_dir: Path,
    nushell_binary: str,
    timeout_seconds: float,
    output_bytes: int,
    cpu_seconds: int,
    memory_bytes: int,
    wrapper: list[str] | None,
    evaluator: Any,
) -> dict[str, Any]:
    expected = expected_bytes(task_id, case["expected"])
    temporary, root, staged, resolved_inputs = _fixture_root(case, task | {"arm": arm}, candidate)
    try:
        if arm == "bash":
            command = ["/bin/bash", "--noprofile", "--norc", str(staged)]
        elif arm == "nushell":
            binary = shutil.which(nushell_binary)
            if not binary:
                return _case_unavailable(task_id, case, "Nushell executable not found")
            command = [binary, "--no-config-file", str(staged)]
        else:
            binary = execute_binary.resolve(strict=True)
            if not binary.is_file() or not os.access(binary, os.X_OK):
                raise PilotError(f"Execute binary is not executable: {binary}")
            command = [str(binary), "run", str(staged)]
            for name, value in sorted({key: value for key, value in resolved_inputs.items() if not key.startswith("env:")}.items()):
                command.extend(("--input", f"{name}={value}"))
            command.extend(("--command-timeout-ms", str(max(1, int(timeout_seconds * 1000))), "--max-output-bytes", str(output_bytes)))
            command.extend(("--manifest-dir", str(manifest_dir)))

        env = {
            "PATH": "/usr/bin:/bin" if wrapper else os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": str(root / "home"),
            "TMPDIR": str(root / "tmp"),
            "LC_ALL": "C",
            "LANG": "C",
            "TZ": "UTC",
        }
        for item in task["inputs"]:
            env[item["environment"]] = resolved_inputs[f"env:{item['environment']}"]
        before = _filesystem_state(root)
        launched = evaluator._wrapped_command(wrapper, root, command) if wrapper else command
        run = evaluator._capture(
            launched,
            root,
            env,
            timeout_s=timeout_seconds,
            output_limit=output_bytes,
            cpu_s=cpu_seconds,
            memory_bytes=memory_bytes,
        )
        after = _filesystem_state(root)
        changed = sorted(
            name for name in before.keys() | after.keys()
            if before.get(name) != after.get(name)
        )
        output_path = task["output_path"]
        output_file = root.joinpath(*Path(output_path).parts)
        actual_output = output_file.read_bytes() if output_file.is_file() and not output_file.is_symlink() else None
        stdout = run.get("stdout", b"")
        stderr = run.get("stderr", b"")
        started = run.get("started") is True
        rc = run.get("returncode")
        exact_state = changed == [output_path] and actual_output == expected
        stdout_matches = stdout == expected
        exit_success = started and rc == 0 and not run.get("timed_out") and not run.get("output_limited")
        status = "unavailable" if not started and rc is None else "pass" if exit_success and stdout_matches and exact_state else "fail"
        effects = {
            "changed_paths": changed,
            "expected_changed_paths": [output_path],
            "changed_path_set_exact_match": changed == [output_path],
            "filesystem_delta_exact_match": exact_state,
            "changed_entries": {
                name: {
                    "before": before.get(name),
                    "after": after.get(name),
                }
                for name in changed
            },
            "output_path": output_path,
            "output_file": _actual_file(output_file),
            "output_file_exact_match": actual_output == expected,
        }
        return {
            "case_id": case["case_id"],
            "status": status,
            "returncode": rc,
            "runner_error": run.get("error"),
            "started": started,
            "timed_out": run.get("timed_out", False),
            "output_limited": run.get("output_limited", False),
            "stdout": {
                "bytes": len(stdout),
                "sha256": sha256_bytes(stdout),
                "base64": base64.b64encode(stdout).decode("ascii"),
            },
            "stderr": {
                "bytes": len(stderr),
                "sha256": sha256_bytes(stderr),
                "base64": base64.b64encode(stderr).decode("ascii"),
            },
            "expected_stdout": {
                "bytes": len(expected),
                "sha256": sha256_bytes(expected),
                "base64": base64.b64encode(expected).decode("ascii"),
            },
            "stdout_exact_match": stdout_matches,
            "stderr_oracle": "not specified by public task; exact bytes captured but not scored",
            "exit_status_success": exit_success,
            "filesystem_effects": effects,
            "generation_timing_relation": "not applicable; runtime timing is not recorded as a pilot metric",
        }
    finally:
        temporary.cleanup()


def _load_evaluator(repo: Path) -> tuple[Any, dict[str, dict[str, Any]], Path, Path]:
    benchmark_dir = repo / "benchmarks" / "ai_productivity"
    package = benchmark_dir / "public-development.json"
    evaluator_path = benchmark_dir / "evaluate.py"
    harness_path = benchmark_dir / "harness.py"
    observed = {
        "public package": sha256_file(package),
        "public evaluator": sha256_file(evaluator_path),
        "public harness": sha256_file(harness_path),
    }
    expected = {
        "public package": PUBLIC_PACKAGE_SHA256,
        "public evaluator": EVALUATOR_SHA256,
        "public harness": HARNESS_SHA256,
    }
    if observed != expected:
        raise PilotError(f"public fixture/evaluator source differs from this adapter's pin: {observed}")
    sys.path.insert(0, str(benchmark_dir))
    import evaluate  # type: ignore[import-not-found]

    tasks = evaluate.load_public_tasks(package)
    if tuple(task for task in TASK_ORDER if task in tasks) != TASK_ORDER or len(tasks) != len(TASK_ORDER):
        raise PilotError("public package task roster differs from the preregistered three-task pilot")
    return evaluate, tasks, package, evaluator_path


def _execute(args: argparse.Namespace) -> dict[str, Any]:
    repo = args.repo.resolve(strict=True)
    evaluate, tasks, package, evaluator_path = _load_evaluator(repo)
    plan_path = CAMPAIGN / "plan.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if plan.get("public_development_json_sha256") != PUBLIC_PACKAGE_SHA256:
        raise PilotError("pilot plan does not pin the current public package")
    amendment_1 = json.loads(AMENDMENT_PATH.read_text(encoding="utf-8"))
    amendment_2 = json.loads(AMENDMENT_2_PATH.read_text(encoding="utf-8"))
    if sha256_file(AMENDMENT_2_PATH) != AMENDMENT_2_SHA256:
        raise PilotError("second pre-execution amendment differs from its reviewed bytes")
    amendment_schema = "execute.ai-productivity.public-pilot-plan-amendment/1"
    if amendment_1.get("schema") != amendment_schema or amendment_2.get("schema") != amendment_schema:
        raise PilotError("pre-execution amendment schema is unsupported")
    plan_sha = sha256_file(plan_path)
    if amendment_1.get("original_plan_sha256") != plan_sha or amendment_2.get("original_plan_sha256") != plan_sha:
        raise PilotError("pre-execution amendment does not bind the unchanged original plan.json")
    dated_plan_sha = sha256_file(CAMPAIGN / "plan-2026-10-15.md")
    if amendment_1.get("dated_plan_sha256") != dated_plan_sha or amendment_2.get("dated_plan_sha256") != dated_plan_sha:
        raise PilotError("dated plan changed after the pre-execution amendment was recorded")
    if amendment_1.get("previous_staged_tree") != plan["root_gate"]["staged_tree"]:
        raise PilotError("first amendment does not identify the staged tree pinned by the original plan")
    if amendment_2.get("previous_amendment") != AMENDMENT_PATH.name or amendment_2.get("previous_amendment_sha256") != sha256_file(AMENDMENT_PATH):
        raise PilotError("second amendment does not extend the byte-pinned first amendment")
    if amendment_2.get("previous_staged_tree") != amendment_1.get("amended_staged_tree"):
        raise PilotError("second amendment does not extend the first amended staged tree")
    if repo != Path(plan["repository"]).resolve(strict=True):
        raise PilotError("repository argument differs from the repository recorded in the pilot plan")
    expected_revision = amendment_2.get("amended_staged_tree")
    if expected_revision != EXPECTED_CURRENT_STAGED_TREE:
        raise PilotError("second amendment does not identify the exact reviewed b2004326 staged tree")
    if args.expected_revision != expected_revision:
        raise PilotError(f"expected revision must match amended staged tree {expected_revision}")
    if not re.fullmatch(r"[a-f0-9]{40}", args.actual_commit_sha):
        raise PilotError("--actual-commit-sha must be a lowercase 40-character Git SHA")
    actual_commit_tree_before = git_commit_tree(repo, args.actual_commit_sha)
    if actual_commit_tree_before != expected_revision:
        raise PilotError("actual commit tree differs from the amended staged tree")
    if not re.fullmatch(r"[a-f0-9]{64}", args.expected_execute_sha256):
        raise PilotError("--expected-execute-sha256 must be a lowercase SHA-256 digest")
    participants = _recorded_participants(CAMPAIGN)
    execute_binary = args.execute.resolve(strict=True)
    if not execute_binary.is_file() or not os.access(execute_binary, os.X_OK):
        raise PilotError(f"Execute binary is not executable: {execute_binary}")
    binary_sha_before = sha256_file(execute_binary)
    if binary_sha_before != args.expected_execute_sha256:
        raise PilotError("Execute binary SHA-256 differs from --expected-execute-sha256")
    manifest_dir = (args.manifest_dir or (repo / "manifests")).resolve(strict=True)
    recorded_manifest_dir = (repo / "manifests").resolve(strict=True)
    if manifest_dir != recorded_manifest_dir:
        raise PilotError("--manifest-dir must be the recorded repository's manifests directory")
    catalog_sha_before = manifest_catalog_digest(manifest_dir)
    if catalog_sha_before != MANIFEST_CATALOG_SHA256:
        raise PilotError("manifest catalog differs from the pilot's pinned recorded-repository digest")
    nushell_path = shutil.which(args.nushell)
    if not nushell_path:
        raise PilotError(f"Nushell executable not found: {args.nushell}")

    if args.sandbox_wrapper_json:
        wrapper = evaluate.parse_sandbox_wrapper(args.sandbox_wrapper_json)
        isolation = "operator supplied wrapper; policy is unverified by evaluator"
    else:
        wrapper = None
        if not args.allow_unsandboxed:
            raise PilotError("select an operator wrapper or pass the explicit --allow-unsandboxed flag")
        isolation = "explicit unsandboxed execution opt-in; not a security sandbox"

    result_participants = []
    for participant in participants:
        task_id = participant["task_id"]
        task = tasks[task_id]
        candidate_path = participant["archive_path"]
        if not candidate_path:
            cases = [_case_unavailable(task_id, case, "initial first-cohort artifact is missing; recovery is kept separate") for case in task["cases"]]
            aggregate = "unavailable"
        else:
            artifact = Path(candidate_path)
            if sha256_file(artifact) != participant["artifact_sha256"]:
                raise PilotError(f"candidate changed after archive verification: {participant['participant_id']}")
            cases = []
            for case in task["cases"]:
                cases.append(_run_case(
                    task_id, task, case, participant["arm"], artifact,
                    execute_binary=execute_binary,
                    manifest_dir=manifest_dir,
                    nushell_binary=args.nushell,
                    timeout_seconds=args.timeout_seconds,
                    output_bytes=args.output_bytes,
                    cpu_seconds=args.cpu_seconds,
                    memory_bytes=args.memory_bytes,
                    wrapper=wrapper,
                    evaluator=evaluate,
                ))
                binary_sha_after = sha256_file(execute_binary)
                catalog_sha_after = manifest_catalog_digest(manifest_dir)
                if binary_sha_after != binary_sha_before or catalog_sha_after != catalog_sha_before:
                    raise PilotError("Execute binary or manifest catalog changed during candidate execution")
            case_statuses = {case["status"] for case in cases}
            aggregate = "pass" if case_statuses == {"pass"} else "unavailable" if case_statuses == {"unavailable"} else "fail"
        result_participants.append({
            **participant,
            "status": aggregate,
            "cases": cases,
        })

    binary_sha_after = sha256_file(execute_binary)
    catalog_sha_after = manifest_catalog_digest(manifest_dir)
    actual_commit_tree_after = git_commit_tree(repo, args.actual_commit_sha)
    if binary_sha_after != binary_sha_before or catalog_sha_after != catalog_sha_before or actual_commit_tree_after != expected_revision:
        raise PilotError("final integrity check found an Execute, manifest-catalog, or commit-tree mismatch")
    return {
        "schema": "execute.ai-productivity.public-generation-pilot/1",
        "trial_type": "public_development_fixture_only",
        "claim": "none",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "pilot_plan_sha256": plan_sha,
        "pre_execution_amendment_sha256": sha256_file(AMENDMENT_PATH),
        "pre_execution_amendment_id": amendment_1["amendment_id"],
        "pre_execution_amendment_2_sha256": sha256_file(AMENDMENT_2_PATH),
        "pre_execution_amendment_2_id": amendment_2["amendment_id"],
        "dispatch_ledger_sha256": sha256_file(CAMPAIGN / "dispatch-ledger.json"),
        "replacement_dispatch_sha256": sha256_file(CAMPAIGN / "replacement-dispatch.json"),
        "public_package_sha256": sha256_file(package),
        "public_evaluator_sha256": sha256_file(evaluator_path),
        "execute_binary_path": str(execute_binary),
        "execute_binary_sha256": binary_sha_before,
        "execute_binary_sha256_before": binary_sha_before,
        "execute_binary_sha256_after": binary_sha_after,
        "expected_execute_sha256": args.expected_execute_sha256,
        "expected_source_revision": args.expected_revision,
        "expected_staged_tree": amendment_2["amended_staged_tree"],
        "actual_commit_sha": args.actual_commit_sha,
        "actual_commit_tree_sha256_before": actual_commit_tree_before,
        "actual_commit_tree_sha256_after": actual_commit_tree_after,
        "manifest_dir": str(manifest_dir),
        "manifest_catalog_sha256_before": catalog_sha_before,
        "manifest_catalog_sha256_after": catalog_sha_after,
        "manifest_catalog_sha256_expected": MANIFEST_CATALOG_SHA256,
        "integrity_binding": "passed; binary and manifest catalog hashes matched before/after candidate execution",
        "nushell_binary_path": str(Path(nushell_path).resolve()),
        "nushell_binary_sha256": sha256_file(Path(nushell_path)),
        "platform": platform.platform(),
        "execution_isolation": isolation,
        "resource_limits": {
            "timeout_seconds": args.timeout_seconds,
            "stdout_stderr_combined_bytes": args.output_bytes,
            "cpu_seconds": args.cpu_seconds,
            "address_space_bytes": args.memory_bytes,
        },
        "timing_and_usage": {
            "generation_wall_clock": "dispatch and return observations are in the pilot ledger; these are external elapsed intervals, not inference latency",
            "inference_latency": "unavailable",
            "tokens": "unavailable",
            "tool_calls": "unavailable",
            "cost": "unavailable",
            "runtime_benchmark": "not performed; execution duration is not emitted as a metric",
        },
        "first_cohort_missing_outcome": "filesystem_inventory__bash remains missing; no replacement substituted in this row",
        "recovery_replacement_outcome": "separate participant row; not counted as a first-cohort artifact",
        "stderr_scoring": "exact bytes and hashes are retained; public task contract does not specify an expected stderr stream",
        "participants": result_participants,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=DEFAULT_REPO)
    parser.add_argument("--execute", type=Path, required=True, help="root-validated combined Execute CLI binary")
    parser.add_argument("--manifest-dir", type=Path, help="defaults to the recorded repository's manifests directory")
    parser.add_argument("--expected-execute-sha256", required=True, help="SHA-256 captured from the freshly validated combined binary")
    parser.add_argument("--expected-revision", required=True, help="must equal the exact staged tree in the pinned second amendment")
    parser.add_argument("--actual-commit-sha", required=True, help="root-provided commit; its Git tree must equal the amended staged tree")
    parser.add_argument(
        "--nushell",
        default=str(CAMPAIGN.parent / "work" / "nushell-0.116.0" / "nu-0.116.0-aarch64-apple-darwin" / "nu"),
    )
    safety = parser.add_mutually_exclusive_group(required=True)
    safety.add_argument("--sandbox-wrapper-json", help="operator-supplied JSON argv wrapper with {workspace} and {command}")
    safety.add_argument("--allow-unsandboxed", action="store_true", help="explicitly opt into running generated candidates with current OS permissions")
    parser.add_argument("--authorize-public-execution", action="store_true", required=True, help="required only after root authorizes the fresh validated combined candidate")
    parser.add_argument("--timeout-seconds", type=float, default=5.0)
    parser.add_argument("--output-bytes", type=int, default=1_048_576)
    parser.add_argument("--cpu-seconds", type=int, default=5)
    parser.add_argument("--memory-bytes", type=int, default=512 * 1024 * 1024)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.timeout_seconds <= 0 or args.output_bytes < 1 or args.cpu_seconds < 1 or args.memory_bytes < 32 * 1024 * 1024:
        parser.error("resource limits must be positive and practical")
    try:
        output = args.out.resolve()
        if output.exists() or output.is_symlink():
            raise PilotError(f"refusing to overwrite evaluation output: {output}")
        record = _execute(args)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        print(f"public pilot evaluation refused/failed: {error}", file=sys.stderr)
        return 2
    counts: dict[str, int] = {}
    for participant in record["participants"]:
        counts[participant["status"]] = counts.get(participant["status"], 0) + 1
    print(json.dumps({"output": str(output), "participant_status_counts": counts, "claim": "none"}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
